#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// Declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 ***********************************************************/
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
	m_loadedTextures = 0;  // Initialize loaded textures count
}

/***********************************************************
 *  ~SceneManager()
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	stbi_set_flip_vertically_on_load(true);

	unsigned char* image = stbi_load(filename, &width, &height, &colorChannels, 0);

	if (image)
	{
		std::cout << "Successfully loaded image: " << filename << ", width: " << width << ", height: " << height << ", channels: " << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			stbi_image_free(image);
			return false;
		}

		glGenerateMipmap(GL_TEXTURE_2D);

		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0);

		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image: " << filename << std::endl;
	return false;
}

/***********************************************************
 *  BindGLTextures()
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glDeleteTextures(1, &m_textureIDs[i].ID);  // Correct deletion method
	}
}

/***********************************************************
 *  FindTextureSlot()
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
		{
			index++;
		}
	}

	return textureSlot;
}

/***********************************************************
 *  SetShaderTexture()
 ***********************************************************/
void SceneManager::SetShaderTexture(std::string textureTag)
{
	if (m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureSlot = FindTextureSlot(textureTag);
		if (textureSlot >= 0)  // Ensure texture slot is valid
		{
			glActiveTexture(GL_TEXTURE0 + textureSlot);  // Activate the correct texture unit
			glBindTexture(GL_TEXTURE_2D, m_textureIDs[textureSlot].ID);  // Bind the texture

			// Pass texture slot to shader
			m_pShaderManager->setSampler2DValue(g_TextureValueName, textureSlot);
		}
		else
		{
			std::cout << "Texture tag not found: " << textureTag << std::endl;
		}
	}
}

/***********************************************************
 *  SetTransformations()
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	scale = glm::scale(scaleXYZ);
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationX * rotationY * rotationZ * scale;

	if (m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		// find the defined material that matches the tag
		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			// pass the material properties into the shader
			m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
			m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}
/***********************************************************
 *  FindMaterial()
 *
 *  This method searches for a material by its tag and
 *  returns the material via a reference parameter.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string materialTag, OBJECT_MATERIAL& outMaterial)
{
	for (const auto& material : m_objectMaterials)
	{
		if (material.tag == materialTag)
		{
			outMaterial = material;
			return true;
		}
	}

	// If material is not found, return false
	return false;
}

/***********************************************************
 *  LoadSceneTextures()
 ***********************************************************/
void SceneManager::LoadSceneTextures()
{
	// Load and bind textures
	if (!CreateGLTexture("Textures/PinkMarble.jpg", "pinkmarble"))
		std::cout << "Failed to load texture: PinkMarble.jpg" << std::endl;
	if (!CreateGLTexture("Textures/BrassTexture.jpg", "brass"))
		std::cout << "Failed to load texture: BrassTexture.jpg" << std::endl;
	if (!CreateGLTexture("Textures/WhiteMarble.jpg", "whitemarble"))
		std::cout << "Failed to load texture: WhiteMarble.jpg" << std::endl;
	if (!CreateGLTexture("Textures/GrayTexture.jpg", "gray"))
		std::cout << "Failed to load texture: GrayTexture.jpg" << std::endl;
	if (!CreateGLTexture("Textures/BlackTexture.jpg", "black"))
		std::cout << "Failed to load texture: BlackTexture.jpg" << std::endl;
	if (!CreateGLTexture("Textures/WhiteTexture.jpg", "white"))
		std::cout << "Failed to load texture: WhiteTexture.jpg" << std::endl;
	if (!CreateGLTexture("Textures/BrownTexture.jpeg", "brown"))
		std::cout << "Failed to load texture: BrownTexture.jpeg" << std::endl;
	if (!CreateGLTexture("Textures/OrangeTexture.jpeg", "orange"))
		std::cout << "Failed to load texture: OrangeTexture.jpeg" << std::endl;

	BindGLTextures();  // Bind all loaded textures to their slots
}
/***********************************************************
  *  DefineObjectMaterials()
  *
  *  This method is used for configuring the various material
  *  settings for all of the objects within the 3D scene.
  ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
	SceneManager::OBJECT_MATERIAL goldMaterial; //Creating the gold object material
	goldMaterial.ambientColor = glm::vec3(0.2f, 0.2f, 0.1f);
	goldMaterial.ambientStrength = 0.4f;
	goldMaterial.diffuseColor = glm::vec3(0.3f, 0.3f, 0.2f);
	goldMaterial.specularColor = glm::vec3(0.6f, 0.5f, 0.4f);
	goldMaterial.shininess = 22.0;
	goldMaterial.tag = "gold";
	m_objectMaterials.push_back(goldMaterial);

	SceneManager::OBJECT_MATERIAL cementMaterial; //Creating the cement object material
	cementMaterial.ambientColor = glm::vec3(0.2f, 0.2f, 0.2f);
	cementMaterial.ambientStrength = 0.2f;
	cementMaterial.diffuseColor = glm::vec3(0.5f, 0.5f, 0.5f);
	cementMaterial.specularColor = glm::vec3(0.4f, 0.4f, 0.4f);
	cementMaterial.shininess = 0.5;
	cementMaterial.tag = "cement";
	m_objectMaterials.push_back(cementMaterial);
	
	SceneManager::OBJECT_MATERIAL woodMaterial;//Creating the wood object material
	woodMaterial.ambientColor = glm::vec3(0.4f, 0.3f, 0.1f);
	woodMaterial.ambientStrength = 0.2f;
	woodMaterial.diffuseColor = glm::vec3(0.3f, 0.2f, 0.1f);
	woodMaterial.specularColor = glm::vec3(0.1f, 0.1f, 0.1f);
	woodMaterial.shininess = 0.3;
	woodMaterial.tag = "wood";
	m_objectMaterials.push_back(woodMaterial);
	
	SceneManager::OBJECT_MATERIAL tileMaterial;//Creating the tile object material
	tileMaterial.ambientColor = glm::vec3(0.2f, 0.3f, 0.4f);
	tileMaterial.ambientStrength = 0.3f;
	tileMaterial.diffuseColor = glm::vec3(0.3f, 0.2f, 0.1f);
	tileMaterial.specularColor = glm::vec3(0.4f, 0.5f, 0.6f);
	tileMaterial.shininess = 25.0;
	tileMaterial.tag = "tile";
	m_objectMaterials.push_back(tileMaterial);
	
	SceneManager::OBJECT_MATERIAL glassMaterial;//Creating the glass object material
	glassMaterial.ambientColor = glm::vec3(0.4f, 0.4f, 0.4f);
	glassMaterial.ambientStrength = 0.3f;
	glassMaterial.diffuseColor = glm::vec3(0.3f, 0.3f, 0.3f);
	glassMaterial.specularColor = glm::vec3(0.6f, 0.6f, 0.6f);
	glassMaterial.shininess = 85.0;
	glassMaterial.tag = "glass";
	m_objectMaterials.push_back(glassMaterial);
	
	SceneManager::OBJECT_MATERIAL clayMaterial;//Creating the clay object material
	clayMaterial.ambientColor = glm::vec3(0.2f, 0.2f, 0.3f);
	clayMaterial.ambientStrength = 0.3f;
	clayMaterial.diffuseColor = glm::vec3(0.4f, 0.4f, 0.5f);
	clayMaterial.specularColor = glm::vec3(0.2f, 0.2f, 0.4f);
	clayMaterial.shininess = 0.5;
	clayMaterial.tag = "clay";
	m_objectMaterials.push_back(clayMaterial);
}

/***********************************************************
 *  SetupSceneLights()
 *
 *  This method is called to add and configure the light
 *  sources for the 3D scene.  There are up to 4 light sources.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	// Position a light in front of the scene
	m_pShaderManager->setVec3Value("lightSources[0].position", 0.0f, 3.0f, 12.0f);  // Position in front of the scene and slightly above
	m_pShaderManager->setVec3Value("lightSources[0].ambientColor", 0.05f, 0.05f, 0.05f);  // Increase ambient light slightly
	m_pShaderManager->setVec3Value("lightSources[0].diffuseColor", 0.6f, 0.6f, 0.6f);  // Brighter diffuse light for clearer shadows
	m_pShaderManager->setVec3Value("lightSources[0].specularColor", 0.8f, 0.8f, 0.8f);  // Stronger specular highlights
	m_pShaderManager->setFloatValue("lightSources[0].focalStrength", 20.0f);  // Moderate focal strength to maintain spread across the scene
	m_pShaderManager->setFloatValue("lightSources[0].specularIntensity", 0.5f);  // Increase specular intensity for shinier surfaces

	// Position a secondary light to the right side to balance lighting and add subtle shadows
	m_pShaderManager->setVec3Value("lightSources[1].position", -7.0f, 3.0f, 10.0f);  // Slightly off to the right and above
	m_pShaderManager->setVec3Value("lightSources[1].ambientColor", 0.03f, 0.03f, 0.03f);  // Still weak ambient to avoid over-lighting
	m_pShaderManager->setVec3Value("lightSources[1].diffuseColor", 0.4f, 0.4f, 0.4f);  // More diffuse light for clearer shadows
	m_pShaderManager->setVec3Value("lightSources[1].specularColor", 0.6f, 0.6f, 0.6f);  // Mid-level specular highlights
	m_pShaderManager->setFloatValue("lightSources[1].focalStrength", 15.0f);  // Low focal strength for wider spread
	m_pShaderManager->setFloatValue("lightSources[1].specularIntensity", 0.3f);  // Subtle specular to avoid over-brightening

	m_pShaderManager->setBoolValue("bUseLighting", true);
}

/***********************************************************
 *  PrepareScene()
 ***********************************************************/
void SceneManager::PrepareScene()
{
	LoadSceneTextures();  // Ensure textures are loaded before scene preparation
	DefineObjectMaterials(); //Ensure Materials are loaded before scene preperation
	SetupSceneLights(); //Ensure Lgihts are loaded before scene preperation

	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadConeMesh();
	m_basicMeshes->LoadTaperedCylinderMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadBoxMesh();
}

/***********************************************************
 *  RenderScene()
 *  This function renders various objects within a scene,
 *  applying transformations, textures, and materials to
 *  different meshes to create a detailed 3D environment.
 ***********************************************************/
void SceneManager::RenderScene()
{
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	// Draw the countertop (large flat surface like a table)
	scaleXYZ = glm::vec3(10.0f, 0.3f, 10.0f);
	positionXYZ = glm::vec3(0.0f, -0.15f, 5.0f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("whitemarble");  // White marble texture for the countertop
	SetShaderMaterial("glass"); // Glass material for a glossy surface
	m_basicMeshes->DrawBoxMesh();

	// Draw the pen body (vertical cylinder representing the pen)
	scaleXYZ = glm::vec3(0.10f, 2.0f, 0.10f);
	positionXYZ = glm::vec3(3.0f, 0.10f, 8.0f);
	XrotationDegrees = 90.0f;  // Rotate the pen vertically
	ZrotationDegrees = 120.0f; // Add tilt to the pen
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("pinkmarble");  // Pink marble texture for aesthetic
	SetShaderMaterial("tile"); // Slightly glowing material (tile)
	m_basicMeshes->DrawCylinderMesh();

	// Draw the tapered part of the pen (smaller cylinder to taper the pen tip)
	scaleXYZ = glm::vec3(0.10f, 0.25f, 0.10f);
	positionXYZ = glm::vec3(1.27f, 0.10f, 7.00f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("brass");  // Brass texture for a metal-like look
	SetShaderMaterial("tile");  // Same material for consistency
	m_basicMeshes->DrawTaperedCylinderMesh();

	// Draw the pen tip (small cone-shaped part at the end of the pen)
	scaleXYZ = glm::vec3(0.05f, 0.10f, 0.05f);
	positionXYZ = glm::vec3(1.06f, 0.10f, 6.88f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("gray");  // Gray texture for a metallic tip
	SetShaderMaterial("tile");  // Same tile material for subtle glow
	m_basicMeshes->DrawConeMesh();

	// Draw the cup base (cylinder for the body of the cup)
	scaleXYZ = glm::vec3(0.7f, 2.00f, 0.7f);
	positionXYZ = glm::vec3(0.25f, 2.00f, 6.5f);
	ZrotationDegrees = 180.0f;  // Flip the base for orientation
	XrotationDegrees = 0.0f;
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("black");  // Black texture for the cup base
	SetShaderMaterial("clay");  // Clay material for a matte finish
	m_basicMeshes->DrawTaperedCylinderMesh();

	// Draw the cup cap (small flat cylinder as a lid on the cup)
	scaleXYZ = glm::vec3(0.72f, 0.15f, 0.72f);
	positionXYZ = glm::vec3(0.25f, 2.0f, 6.5f);
	ZrotationDegrees = 180.0f;
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("black");  // Match texture to the base
	SetShaderMaterial("clay");  // Same material for consistency
	m_basicMeshes->DrawCylinderMesh();

	// Draw the cup straw (thin cylinder for a straw)
	scaleXYZ = glm::vec3(0.05f, 2.0f, 0.05f);
	positionXYZ = glm::vec3(0.25f, 2.5f, 6.5f);
	ZrotationDegrees = 180.0f;
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("black");  // Match texture with the cup
	SetShaderMaterial("glass");  // Changed to glass to make the straw appear shiny like my scene
	m_basicMeshes->DrawCylinderMesh();

	// Draw the paper towel outer layer (large cylinder to represent paper towel roll)
	scaleXYZ = glm::vec3(0.75f, 2.75f, 0.75f);
	positionXYZ = glm::vec3(-1.5f, 2.75f, 7.0f);
	ZrotationDegrees = 180.0f;
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("white");  // White texture for paper towel
	SetShaderMaterial("glass");  // Glass material for a reflective finish, making it look bright white.
	m_basicMeshes->DrawCylinderMesh();

	// Draw the paper towel inner layer (smaller cylinder inside the roll)
	scaleXYZ = glm::vec3(0.20f, 2.75f, 0.20f);
	positionXYZ = glm::vec3(-1.5f, 2.7501f, 7.0f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("brown");  // Brown texture for cardboard inner roll
	SetShaderMaterial("glass");  // Same reflective material
	m_basicMeshes->DrawCylinderMesh();

	// Draw the coaster (flat disc in front of the cup)
	scaleXYZ = glm::vec3(0.5f, 0.02f, 0.5f);
	positionXYZ = glm::vec3(0.25f, 0.02f, 8.25f);
	ZrotationDegrees = 180.0f;
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("orange");  // Orange texture for a pop of color
	m_basicMeshes->DrawCylinderMesh();
}
