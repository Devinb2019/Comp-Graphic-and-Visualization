///////////////////////////////////////////////////////////////////////////////
// viewmanager.h
// ============
// manage the viewing of 3D objects within the viewport
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#pragma once

#include "ShaderManager.h"
#include "camera.h"

// GLFW library
#include "GLFW/glfw3.h" 

// Enum to track the current projection mode (perspective or orthographic)
enum class ProjectionMode
{
	PERSPECTIVE,
	ORTHOGRAPHIC
};

class ViewManager
{
public:
	// Constructor
	ViewManager(ShaderManager* pShaderManager);

	// Destructor
	~ViewManager();

	// Mouse position callback for mouse interaction with the 3D scene
	static void Mouse_Position_Callback(GLFWwindow* window, double xMousePos, double yMousePos);

	// Scroll callback for adjusting camera movement speed
	static void Scroll_Callback(GLFWwindow* window, double xOffset, double yOffset);

private:
	// Pointer to shader manager object
	ShaderManager* m_pShaderManager;

	// Active OpenGL display window
	GLFWwindow* m_pWindow;

	// Enum to store current projection mode (default is perspective)
	ProjectionMode currentProjectionMode = ProjectionMode::PERSPECTIVE; // Start with perspective mode

	// Process keyboard events for interaction with the 3D scene
	void ProcessKeyboardEvents();

public:
	// Create the initial OpenGL display window
	GLFWwindow* CreateDisplayWindow(const char* windowTitle);

	// Prepare the conversion from 3D object display to 2D scene display
	void PrepareSceneView();
};
