#include "ViewManager.h"
#include <GLFW/glfw3.h>
#include <glm/gtc/matrix_transform.hpp>
#include <iostream>

// Define necessary constants and variables
namespace
{
	// Window dimensions
	const int WINDOW_WIDTH = 1000;
	const int WINDOW_HEIGHT = 800;
	const char* g_ViewName = "view";
	const char* g_ProjectionName = "projection";

	// Global camera pointer
	Camera* g_pCamera = nullptr;

	// Mouse state variables
	float gLastX = WINDOW_WIDTH / 2.0f;
	float gLastY = WINDOW_HEIGHT / 2.0f;
	bool gFirstMouse = true;

	// Time management variables for delta time
	float gDeltaTime = 0.0f;
	float gLastFrame = 0.0f;

	// Projection type toggle (used for orthographic vs perspective switching)
	bool bOrthographicProjection = false;
}

/***********************************************************
 *  ViewManager()
 *  Constructor: Initialize camera and default view settings
 ***********************************************************/
ViewManager::ViewManager(ShaderManager* pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_pWindow = NULL;
	g_pCamera = new Camera();
	g_pCamera->Position = glm::vec3(0.5f, 5.5f, 10.0f); // Initial camera position
	g_pCamera->Front = glm::vec3(0.0f, -0.5f, -2.0f);    // Initial direction
	g_pCamera->Up = glm::vec3(0.0f, 1.0f, 0.0f);         // World up vector
	g_pCamera->Zoom = 80;                                // Initial zoom level
}

/***********************************************************
 *  ~ViewManager()
 *  Destructor: Clean up camera resources
 ***********************************************************/
ViewManager::~ViewManager()
{
	if (g_pCamera)
	{
		delete g_pCamera;
		g_pCamera = nullptr;
	}
}

/***********************************************************
 *  CreateDisplayWindow()
 *  Creates the GLFW display window and sets up mouse events
 ***********************************************************/
GLFWwindow* ViewManager::CreateDisplayWindow(const char* windowTitle)
{
	GLFWwindow* window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, windowTitle, NULL, NULL);
	if (!window)
	{
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		return nullptr;
	}
	glfwMakeContextCurrent(window);

	// Set mouse movement and scroll callbacks for camera interaction
	glfwSetCursorPosCallback(window, &ViewManager::Mouse_Position_Callback);
	glfwSetScrollCallback(window, &ViewManager::Scroll_Callback);

	// Capture the mouse to prevent leaving the window
	glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

	// Enable transparency in OpenGL rendering
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	m_pWindow = window;

	return window;
}

/***********************************************************
 *  Mouse_Position_Callback()
 *  Handles mouse movement to change the camera orientation
 ***********************************************************/
void ViewManager::Mouse_Position_Callback(GLFWwindow* window, double xMousePos, double yMousePos)
{
	// First time mouse movement should initialize positions
	if (gFirstMouse)
	{
		gLastX = xMousePos;
		gLastY = yMousePos;
		gFirstMouse = false;
	}

	// Calculate how much the mouse moved
	float xOffset = xMousePos - gLastX;
	float yOffset = gLastY - yMousePos; // Reversed since y-coordinates range from bottom to top

	// Update last mouse position
	gLastX = xMousePos;
	gLastY = yMousePos;

	// Pass mouse movement to camera for rotation
	g_pCamera->ProcessMouseMovement(xOffset, yOffset);
}

/***********************************************************
 *  Scroll_Callback()
 *  Handles mouse scroll to adjust camera movement speed
 ***********************************************************/
void ViewManager::Scroll_Callback(GLFWwindow* window, double xOffset, double yOffset)
{
	// Adjust movement speed based on scroll direction
	g_pCamera->ProcessMouseScroll(yOffset);
}

/***********************************************************
 *  ProcessKeyboardEvents()
 *  Handles keyboard inputs for camera movement (WASD + QE)
 ***********************************************************/
void ViewManager::ProcessKeyboardEvents()
{
	// Exit program if ESC is pressed
	if (glfwGetKey(m_pWindow, GLFW_KEY_ESCAPE) == GLFW_PRESS)
	{
		glfwSetWindowShouldClose(m_pWindow, true);
	}

	if (!g_pCamera) return;

	// Calculate camera speed based on delta time
	const float cameraSpeed = 2.5f * gDeltaTime;

	// Move camera based on WASD keys
	if (glfwGetKey(m_pWindow, GLFW_KEY_W) == GLFW_PRESS)
		g_pCamera->ProcessKeyboard(FORWARD, gDeltaTime);
	if (glfwGetKey(m_pWindow, GLFW_KEY_S) == GLFW_PRESS)
		g_pCamera->ProcessKeyboard(BACKWARD, gDeltaTime);
	if (glfwGetKey(m_pWindow, GLFW_KEY_A) == GLFW_PRESS)
		g_pCamera->ProcessKeyboard(LEFT, gDeltaTime);
	if (glfwGetKey(m_pWindow, GLFW_KEY_D) == GLFW_PRESS)
		g_pCamera->ProcessKeyboard(RIGHT, gDeltaTime);

	// Move camera vertically using Q and E keys
	if (glfwGetKey(m_pWindow, GLFW_KEY_Q) == GLFW_PRESS)
		g_pCamera->ProcessKeyboard(DOWN, gDeltaTime);
	if (glfwGetKey(m_pWindow, GLFW_KEY_E) == GLFW_PRESS)
		g_pCamera->ProcessKeyboard(UP, gDeltaTime);

	// Switch to perspective projection
	if (glfwGetKey(m_pWindow, GLFW_KEY_P) == GLFW_PRESS)
	{
		currentProjectionMode = ProjectionMode::PERSPECTIVE;
	}

	// Switch to orthographic projection
	if (glfwGetKey(m_pWindow, GLFW_KEY_O) == GLFW_PRESS)
	{
		currentProjectionMode = ProjectionMode::ORTHOGRAPHIC;
	}
}

/***********************************************************
 *  PrepareSceneView()
 *  Updates view and projection matrices based on camera
 ***********************************************************/
void ViewManager::PrepareSceneView()
{
	// Calculate delta time between frames for smooth movement
	float currentFrame = glfwGetTime();
	gDeltaTime = currentFrame - gLastFrame;
	gLastFrame = currentFrame;

	// Process keyboard inputs for movement and projection switching
	ProcessKeyboardEvents();

	glm::mat4 view;
	glm::mat4 projection;

	// Set the projection matrix based on the current projection mode
	if (currentProjectionMode == ProjectionMode::PERSPECTIVE)
	{
		// Perspective projection: typical 3D view
		view = g_pCamera->GetViewMatrix();
		projection = glm::perspective(glm::radians(g_pCamera->Zoom), (float)WINDOW_WIDTH / WINDOW_HEIGHT, 0.1f, 100.0f);
	}
	else if (currentProjectionMode == ProjectionMode::ORTHOGRAPHIC)
	{
		// Orthographic projection: Front-facing view of the pen

		// Set the camera position directly in front of the pen (Z-axis)
		g_pCamera->Position = glm::vec3(0.0f, 1.0f, 15.0f);  // Move the camera to (0, 1, 15)
		g_pCamera->Front = glm::vec3(0.0f, 0.0f, -1.0f);     // Look directly along the negative Z-axis

		// Recalculate the view matrix based on the new position and direction
		view = glm::lookAt(g_pCamera->Position, g_pCamera->Position + g_pCamera->Front, g_pCamera->Up);

		// Orthographic projection settings (adjust the ortho size as needed)
		float orthoSize = 10.0f;  // This controls the size of the orthographic view
		projection = glm::ortho(-orthoSize, orthoSize, -orthoSize / ((float)WINDOW_WIDTH / WINDOW_HEIGHT), orthoSize / ((float)WINDOW_WIDTH / WINDOW_HEIGHT), 0.1f, 100.0f);
	}

	// Set the view and projection matrices in the shader
	if (m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ViewName, view);
		m_pShaderManager->setMat4Value(g_ProjectionName, projection);
		m_pShaderManager->setVec3Value("viewPosition", g_pCamera->Position);
	}
}
